/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
// GRADO EN INGENIER�A INFORM�TICA
//
// CURSO 2014-2015
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACI�N E INTELIGENCIA ARTIFICIAL
//
// EXAMEN PR�CTICO 1 - NOVIEMBRE 2014
// PROBLEMA 1 (vectores, funciones)
// 
/*****************************************************************************/

#include <iostream>
#include <iomanip>
using namespace std;

// NO EMPLEAR VARIABLES GLOBALES

/*****************************************************************************/

double Dp (int v, double t, double inclinacion)
{
	// Se emplea un vector para los coeficientes de rozamiento longitudinal
	// V (km/h)   40    60    80    100   120   140
	// fl       0.432 0.390 0.348 0.320 0.291 0.263
	// 
	// Acceso: Calculemos, dada la velocidad, v, qu� casilla le toca: 
	// 40->0, 60->1, 80->2,..
	// Tienen m�ximo com�n divisor=20. v/20--> 40/20=2, 60/20=3, 80/20=4,... 
	// (v/20)-2 --> (40/20)-2=0, (60/20)-2=1, (80/20)-2=2,... 
			
	const int NUM_FLS = 6;
	double fls [NUM_FLS] = {0.432, 0.390, 0.348, 0.320, 0.291, 0.263};
	
	double fl = fls[(v/20)-2];
				
	return ((v*t)/3.6) + ((v*v)/(254*(fl+inclinacion)));

}
	
/*****************************************************************************/

int main (void)
{
	const int V_MIN  =  40;
	const int V_MAX  = 140;
	const int INCR_V =  20;
	const double TIEMPO_STD = 2.0;

	
	cout.setf(ios::fixed);		// Notaci�n de punto fijo para los reales
	cout.setf(ios::showpoint);	// Mostrar siempre decimales 


	// Lectura de la inclinaci�n de la rasante 
	
	double inclinacion;
		
	do {
		cout << "Inclinaci�n de la rasante (porcentaje): "; 
		cin >> inclinacion;
	} while ((inclinacion < -25.0) || (inclinacion > 25.0));
	
	inclinacion = inclinacion/100.0;
	
	cout << "Inclinaci�n de la rasante: " 
		 << setw(6) << setprecision(2) << inclinacion;
	cout << endl << endl; 	
	

	// PRIMER APARTADO
	
	// Lectura de los valores de tiempos de percepci�n y reacci�n 
	
	double tiempo_1, tiempo_2;
	double min_tiempo, max_tiempo;
	double incremento;
	
	cout << "Introduzca los extremos del intervalo de tiempos." << endl; 	

	do {
		cout << "\tTiempo en segundos (extremo 1): "; 
		cin >> tiempo_1;
	} while (tiempo_1 < 0);
	
	do {
		cout << "\tTiempo en segundos (extremo 2): "; 
		cin >> tiempo_2;
	} while (tiempo_2 < 0);
	
	if (tiempo_1 < tiempo_2) {
		min_tiempo = tiempo_1;
		max_tiempo = tiempo_2;		
	}
	else {
		min_tiempo = tiempo_2;
		max_tiempo = tiempo_1;		
	}

	do {
		cout << "\tIncremento de tiempo (segundos): " ; 	
		cin >> incremento;
	} while (incremento <= 0);

	cout << "Estudiando entre " 
		 << setw(5) << setprecision(2) << min_tiempo << " s y "
		 << setw(5) << setprecision(2) << max_tiempo << " s. "
		 << "Incr = " << setw(5) << setprecision(2) << incremento << " s.";
	cout << endl << endl;
		
	
	for (double tp=min_tiempo; tp<=max_tiempo; tp+=incremento) {
	
		cout << "Experimento para t = " 
			 << setw(6) << setprecision(2) << tp << endl; 	
	
		for (int v=V_MIN; v<=V_MAX; v+=INCR_V) {	 
			
			double dp = Dp (v, tp, inclinacion);
			
			cout << "\tv = " << setw(4) << v << " km/h. ---> Dp = " 
				 << setw(8) << setprecision(2) << dp << " m." << endl; 	
		
		} // for v
		
	} // for tp
		
	cout << endl << endl;	
		
	
	// SEGUNDO APARTADO

	cout << "Comparativa con el tiempo medio (2s). " << endl; 	
	
	double tiempo; 
	
	do {
		cout << "\tIntroduzca tiempo (en segundos): "; 	
		cin >> tiempo;
	} while (tiempo < TIEMPO_STD);
	
	cout << endl;
	cout << "Experimento para t = " 
		 << setw(6) << setprecision(2) << tiempo << endl; 	
			 
	for (int v=V_MIN; v<=V_MAX; v+=INCR_V) {	 
			
		double dp_std = Dp (v, TIEMPO_STD, inclinacion);
		double dp     = Dp (v, tiempo, inclinacion);
			
		cout << "v = " << setw(4) << v << " km/h. ---> Dp = " 
			 << setw(8) << setprecision(2) << dp_std 
			 << " m. (" << TIEMPO_STD <<" s) - "; 
		cout << setw(8) << setprecision(2) << dp 
			 << " m. (" << tiempo <<" s)";
		cout << endl;
			  	
	} // for v		
	
	cout << endl << endl;

	return (0);
} 
