/*****************************************************************************/
// FUNDAMENTOS DE PROGRAMACI�N
// GRADO EN INGENIER�A INFORM�TICA
//
// CURSO 2014-2015
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACI�N E INTELIGENCIA ARTIFICIAL
//
// EXAMEN PR�CTICO 1 - NOVIEMBRE 2014
// PROBLEMA 1
// 
/*****************************************************************************/

#include <iostream>
#include <iomanip>
using namespace std;

// NO EMPLEAR VARIABLES GLOBALES

/*****************************************************************************/
int main (void)
{

	const int V_MIN  =  40;
	const int V_MAX  = 140;
	const int INCR_V =  20;
	const double TIEMPO_STD = 2.0;
	
	
	cout.setf(ios::fixed);		// Notaci�n de punto fijo para los reales
	cout.setf(ios::showpoint);	// Mostrar siempre decimales 



	// Lectura de la inclinaci�n de la rasante 
	
	double inclinacion;
		
	do {
		cout << "Inclinaci�n de la rasante (porcentaje): "; 
		cin >> inclinacion;
	} while ((inclinacion < -25.0) || (inclinacion > 25.0));
	
	inclinacion = inclinacion/100.0;
	
	cout << "Inclinaci�n de la rasante: " 
		 << setw(6) << setprecision(2) << inclinacion;
	cout << endl << endl; 	
	

	// PRIMER APARTADO
	
	// Lectura de los valores de tiempos de percepci�n y reacci�n 
	
	double tiempo_1, tiempo_2;
	double min_tiempo, max_tiempo;
	double incremento;
	
	cout << "Introduzca los extremos del intervalo de tiempos." << endl; 	

	do {
		cout << "\tTiempo en segundos (extremo 1): "; 
		cin >> tiempo_1;
	} while (tiempo_1 < 0);
	
	do {
		cout << "\tTiempo en segundos (extremo 2): "; 
		cin >> tiempo_2;
	} while (tiempo_2 < 0);
	
	if (tiempo_1 < tiempo_2) {
		min_tiempo = tiempo_1;
		max_tiempo = tiempo_2;		
	}
	else {
		min_tiempo = tiempo_2;
		max_tiempo = tiempo_1;		
	}

	do {
		cout << "\tIncremento de tiempo (segundos): " ; 	
		cin >> incremento;
	} while (incremento <= 0);

	cout << "Estudiando entre " 
		 << setw(5) << setprecision(2) << min_tiempo << " s y "
		 << setw(5) << setprecision(2) << max_tiempo << " s. "
		 << "Incr = " << setw(5) << setprecision(2) << incremento << " s.";
	cout << endl << endl;
		
	
	for (double tp=min_tiempo; tp<=max_tiempo; tp+=incremento) {
	
		cout << "Experimento para t = " 
			 << setw(6) << setprecision(2) << tp << endl; 	
	
		for (int v=V_MIN; v<=V_MAX; v+=INCR_V) {	 
			
			double fl; // Se calcula en base a la velocidad	
					
			switch (v) {
				case ( 40) : fl = 0.432;
							 break; 
				case ( 60) : fl = 0.390;
							 break; 				
				case ( 80) : fl = 0.348; 
							 break; 
				case (100) : fl = 0.320; 
							 break; 
				case (120) : fl = 0.291; 
							 break; 
				case (140) : fl = 0.263; 
							 break; 	
			}		

			double Dp = ((v*tp)/3.6) + ((v*v)/(254*(fl+inclinacion)));
			
			cout << "\tv = " << setw(4) << v << " km/h. ---> Dp = " 
				 << setw(8) << setprecision(2) << Dp << " m." << endl; 	
		
		} // for v
		
	} // for tp
		
	cout << endl << endl;	
		
	
	// SEGUNDO APARTADO

	cout << "Comparativa con el tiempo medio (2s). " << endl; 	
	
	double tiempo; 
	
	do {
		cout << "\tIntroduzca tiempo (en segundos): "; 	
		cin >> tiempo;
	} while (tiempo < TIEMPO_STD);
	
	cout << endl;
	cout << "Experimento para t = " 
		 << setw(6) << setprecision(2) << tiempo << endl; 	
			 
	for (int v=V_MIN; v<=V_MAX; v+=INCR_V) {	 
			
		double fl; // Se calcula en base a la velocidad	
						
		switch (v) {
			case ( 40) : fl = 0.432;
						 break; 
			case ( 60) : fl = 0.390;
						 break; 				
			case ( 80) : fl = 0.348; 
						 break; 
			case (100) : fl = 0.320; 
						 break; 
			case (120) : fl = 0.291; 
						 break; 
			case (140) : fl = 0.263; 
						 break; 	
		}		

		double Dp_std = ((v*TIEMPO_STD)/3.6) + ((v*v)/(254*(fl+inclinacion)));
		double Dp = ((v*tiempo)/3.6) + ((v*v)/(254*(fl+inclinacion)));
				
		cout << "v = " << setw(4) << v << " km/h. ---> Dp = " 
			 << setw(8) << setprecision(2) << Dp_std 
			 << " m. (" << TIEMPO_STD <<" s) - "; 
		cout << setw(8) << setprecision(2) << Dp 
			 << " m. (" << tiempo <<" s)";
		cout << endl;
			  	
	} // for v		
	
	cout << endl << endl;

	return (0);
} 
