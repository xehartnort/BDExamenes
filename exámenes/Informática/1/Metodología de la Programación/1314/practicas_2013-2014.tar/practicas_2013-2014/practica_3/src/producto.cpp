/*********************************************************************/
// METODOLOGIA DE LA PROGRAMACION
// GRADO EN INGENIERIA INFORMATICA
//
// CURSO 2012-2013
// (C) FRANCISCO JOSE CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACION E INTELIGENCIA ARTIFICIAL
//
// opers.cpp
//
/*********************************************************************/

#include "producto.h"
using namespace std;


/*********************************************************************/

int resta (int a, int b)
{
   return (a-b); 
}


/*********************************************************************/

int divide (int a, int b)
{
   return (a/b); 
}

/*********************************************************************/ 
