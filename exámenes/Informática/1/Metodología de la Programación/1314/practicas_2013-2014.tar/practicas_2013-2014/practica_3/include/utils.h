/*********************************************************************/
// METODOLOG�A DE LA PROGRAMACI�N
// GRADO EN INGENIER�A INFORM�TICA
//
// CURSO 2013-2014
// (C) FRANCISCO JOS� CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACI�N E INTELIGENCIA ARTIFICIAL
//
// PR�CTICA 1
/*	
	Ejemplo de fichero .h
*/
/*********************************************************************/

#ifndef UTILS
#define UTILS

/*********************************************************************/
// Calcula la divisi�n entera 
// PRE: dividendo > 0  y divisor > 0 

int DivisionEntera (int dividendo, int divisor);

/*********************************************************************/
// Calcula el resto de la divisi�n entera 
// PRE: dividendo > 0  y divisor > 0 

int RestoDivision (int dividendo, int divisor);

#endif 
