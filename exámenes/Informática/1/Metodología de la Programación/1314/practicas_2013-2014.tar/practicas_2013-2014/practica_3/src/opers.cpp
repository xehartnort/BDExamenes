/*********************************************************************/
// METODOLOGIA DE LA PROGRAMACION
// GRADO EN INGENIERIA INFORMATICA
//
// CURSO 2012-2013
// (C) FRANCISCO JOSE CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACION E INTELIGENCIA ARTIFICIAL
//
// opers.cpp
//
/*********************************************************************/

#include "opers.h"
using namespace std;

/*********************************************************************/

int suma (int a, int b)
{
   return (a+b); 
}

/*********************************************************************/

int resta (int a, int b)
{
   return (a-b); 
}

/*********************************************************************/

int multiplica (int a, int b)
{
   return (a*b); 
}

/*********************************************************************/

int divide (int a, int b)
{
   return (a/b); 
}

/*********************************************************************/ 
