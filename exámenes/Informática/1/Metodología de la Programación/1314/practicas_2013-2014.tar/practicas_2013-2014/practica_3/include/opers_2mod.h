/*********************************************************************/
// METODOLOGIA DE LA PROGRAMACION
// GRADO EN INGENIERIA INFORMATICA
//
// CURSO 2012-2013
// (C) FRANCISCO JOSE CORTIJO BON
// DEPARTAMENTO DE CIENCIAS DE LA COMPUTACION E INTELIGENCIA ARTIFICIAL
//
// opers_2mod.h
//
/*********************************************************************/

#ifndef OPERS_2MOD
#define OPERS_2MOD

int suma (int, int);
int resta (int, int);
int multiplica (int, int);
int divide (int, int);

#endif
 
